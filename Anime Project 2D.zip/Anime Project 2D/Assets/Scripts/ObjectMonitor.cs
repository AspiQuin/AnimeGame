﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectMonitor : MonoBehaviour {

    public Collider2D playerAbove, playerBelow;
    public static Transform player;
    SpriteRenderer sr;

    private void Awake()
    {
        if (player == null)
        {
            player = GameObject.FindGameObjectWithTag("Player").transform;
        }
        sr = GetComponent<SpriteRenderer>();
    }


    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		if(Vector3.Distance(transform.position, player.position) < 20.0f)
        {
            decideColliderToUse();
            decideSortingOrder();
        }
	}
    void decideSortingOrder()
    {
        sr.sortingOrder = (int)Camera.main.WorldToScreenPoint(transform.position).y * -1;
    }
    void decideColliderToUse()
    {
        if (player.transform.position.y > transform.position.y)
        {
            playerAbove.enabled = true;
            playerBelow.enabled = false;
        } else
        {
            playerAbove.enabled = false;
            playerBelow.enabled = true;
        }
    }
}
